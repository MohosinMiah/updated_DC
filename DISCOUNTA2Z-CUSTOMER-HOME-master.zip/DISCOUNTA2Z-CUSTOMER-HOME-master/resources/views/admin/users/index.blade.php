@extends('admin.main.main')

@section('title', 'Admin Login')


@section('main_body')

    {{-- Main  Section  --}}

<div class="container form_style">
    <div class="row ">
  
  
  <h1> Admin Dashboard</h1>

    </div>
  </div>

  @stop
